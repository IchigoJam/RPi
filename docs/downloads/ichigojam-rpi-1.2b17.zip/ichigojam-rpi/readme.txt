=================================
====   IchigoJam BASIC RPi   ====
=================================
version 1.2.5 (2018.01.19)

Raspberry Pi Edition of the software of the Kids PC "IchigoJam"
http://ichigojam.net/index-en.html


1. Terms of use
2. Device compatibility
3. How to use
4. Support
5. License of using libs



[1. Terms of use]

You have to agree "IchigoJam ロイヤリティフリープログラム利用規約"
ichigojam-license.pdf
https://ichigojam.net/download.html

You can
	upgrade your microSD card you bought
	write to the microSD card for own use
	details: license agreement

You can't
	upload this software another site
	share this software for another
	details: license agreement



[2. Device compatibility]

Compatibility is confirmed with the following devices.

Raspberry Pi 3 Model B V1.2
Raspberry Pi Zero W V1.1
Raspberry Pi Zero V1.3
Raspberry Pi 2 Model B V1.2
Raspberry Pi Model B+ V1.2
Raspberry Pi Model A+ V1.1



[3. How to use]

Format a microSD card with FAT32.
Copy contents of the directory including this readme.txt to the microSD card.

Detailed documentation
https://ichigojam.github.io/RPi/



[4. Support]

https://www.facebook.com/groups/ichigojamfan/
http://na-s.jp



[5. License of using libs]

Ultibo
  Development environment
  https://ultibo.org/




* Raspberry Pi is a trademark of the Raspberry Pi Foundation.


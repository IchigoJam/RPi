=================================
====   IchigoJam BASIC RPi   ====
=================================
version 1.2.5 (2018.05.31)

「こどもパソコンIchigoJam」のソフトウェアの Raspberry Pi 版です。
http://ichigojam.net/


1. 利用条件
2. 対応機種
3. 使い方
4. サポート
5. ライセンス表示



[1. 利用条件]

「IchigoJam ロイヤリティフリープログラム利用規約」に同意いただきご利用ください。
ichigojam-license.pdf
https://ichigojam.net/download.html

できること
	購入いただいた microSDメモリーカード をバージョンアップする
	別途用意した microSDメモリーカード に書き込みご自身で使う
	詳細は利用規約をご参照ください

できないこと
	他のサイトへ転載はできません
	書き込んだ microSDメモリーカード を第三者に提供する場合、別途契約が必要です
	詳細は利用規約をご参照ください



[2. 対応機種]

下記の機種で動作確認しています。

Raspberry Pi 3 Model B+
Raspberry Pi 3 Model B V1.2
Raspberry Pi Zero W V1.1
Raspberry Pi Zero V1.3
Raspberry Pi 2 Model B V1.2
Raspberry Pi Model B+ V1.2
Raspberry Pi Model A+ V1.1



[3. 使い方]

microSDメモリーカード を FAT32 でフォーマットし、
この readme_ja.txt を含むディレクトリの中身をコピーします。

詳しいドキュメントはこちらです。
https://ichigojam.github.io/RPi/index_ja.html



[4. サポート]

詳細は、Facebookグループ IchigoJam-FAN または ナチュラルスタイル までお問い合わせください
https://www.facebook.com/groups/ichigojam/
http://na-s.jp



[5. ライセンス表示]

Ultibo
  開発環境として利用しています
  https://ultibo.org/




* Raspberry Pi は Raspberry Pi財団の商標です。
* Raspberry Pi is a trademark of the Raspberry Pi Foundation.

